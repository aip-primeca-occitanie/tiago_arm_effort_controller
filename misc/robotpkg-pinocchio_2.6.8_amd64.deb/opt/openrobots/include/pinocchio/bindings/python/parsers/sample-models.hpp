//
// Copyright (c) 2015-2020 CNRS INRIA
//

#ifndef __pinocchio_python_sample_models_hpp__
#define __pinocchio_python_sample_models_hpp__

namespace pinocchio
{
  namespace python
  {
    void exposeSampleModels();
  }
} // namespace pinocchio::python

#endif // ifndef __pinocchio_python_sample_models_hpp__
