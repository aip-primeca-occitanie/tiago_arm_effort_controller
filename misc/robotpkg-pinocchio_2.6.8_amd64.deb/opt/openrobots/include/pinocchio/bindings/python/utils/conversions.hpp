//
// Copyright (c) 2019 CNRS
//

namespace pinocchio
{
  namespace python
  {

    void exposeConversions();

  } // namespace python
} // namespace pinocchio
