//
// Copyright (c) 2018 INRIA
//

#ifndef __pinocchio_deprecated_namespaces_hpp__
#define __pinocchio_deprecated_namespaces_hpp__

#if PINOCCHIO_ENABLE_COMPATIBILITY_WITH_VERSION_1 // do not warn
  namespace se3 = ::pinocchio;
#endif

#endif // ifndef __pinocchio_deprecated_namespaces_hpp__
